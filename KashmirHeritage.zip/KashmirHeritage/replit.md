# Kashmir Heritage Website

## Overview
This is a modern single-page React application showcasing Kashmiri culture, history, and heritage. The application features an interactive Bento-style grid layout with animated components, built using React, Vite, and Tailwind CSS. It serves as a cultural portal highlighting various aspects of Kashmir including historic sites, traditional arts, cuisine, language, and contemporary news.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom Kashmir-themed color palette
- **UI Components**: Radix UI components via shadcn/ui design system
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **API Structure**: RESTful endpoints with `/api` prefix

### Key Components

#### Layout Structure
- **Hero Section**: Full-width animated background with gradient Kashmir branding
- **MagicBento Grid**: Interactive animated grid showcasing different heritage topics
- **Floating Search**: Expandable search component for heritage content
- **Footer**: Links and social media integration

#### Bento Grid Sections
1. **Kashmir Today**: News and current events
2. **Historic Sites**: Monuments and archaeological sites
3. **Art & Handicrafts**: Traditional crafts like Pashmina, papier-mâché
4. **Music & Literature**: Sufiana music, poetry, cultural expressions
5. **Traditional Attire**: Clothing and ceremonial wear
6. **Cuisine**: Traditional dishes and culinary heritage
7. **Language & Scripts**: Sharada script, Kashmiri language preservation
8. **Timeline**: Interactive historical timeline

### Data Flow
1. **Static Content**: Heritage information rendered from predefined data structures
2. **Dynamic Animations**: CSS-based animations with GSAP integration hooks
3. **Search Functionality**: Client-side filtering of heritage content
4. **Responsive Design**: Mobile-first approach with adaptive grid layouts

### External Dependencies

#### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight routing
- **class-variance-authority**: Component variant management
- **tailwindcss**: Utility-first CSS framework

#### UI/UX Dependencies
- **@radix-ui/\***: Accessible UI primitives
- **lucide-react**: Icon library
- **embla-carousel-react**: Carousel functionality
- **date-fns**: Date formatting utilities

#### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type checking
- **tsx**: TypeScript execution
- **esbuild**: Fast bundling for production

### Deployment Strategy

#### Development
- **Local Development**: Vite dev server with HMR
- **Environment Variables**: DATABASE_URL for PostgreSQL connection
- **Build Process**: TypeScript compilation with Vite bundling

#### Production
- **Build Command**: `npm run build` - Creates optimized client bundle and server build
- **Start Command**: `npm start` - Runs production Express server
- **Static Assets**: Served from `dist/public` directory
- **Server Bundle**: ESM format with external package resolution

#### Database Management
- **Schema Location**: `shared/schema.ts` for type-safe database definitions
- **Migrations**: Drizzle migrations in `./migrations` directory
- **Database Push**: `npm run db:push` for schema synchronization

#### Configuration Files
- **TypeScript**: Configured for client, server, and shared code
- **Tailwind**: Custom Kashmir-themed color palette and design tokens
- **Vite**: Optimized for React with path aliases and build optimization
- **Drizzle**: PostgreSQL dialect with Neon Database integration

### Notable Architectural Decisions

1. **Monorepo Structure**: Client, server, and shared code in single repository for easier development and type sharing

2. **Shared Schema**: Database schema definitions shared between client and server for type safety

3. **CSS Variables**: Extensive use of CSS custom properties for theming and responsive design

4. **Component Architecture**: Modular Bento box components with expandable content for scalable content management

5. **Animation Strategy**: CSS-based animations with hooks for potential GSAP integration, providing smooth performance

6. **Responsive Design**: Mobile-first approach with adaptive grid layouts for optimal viewing across devices