export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="grid grid-cols-8 grid-rows-6 h-full gap-2 p-4">
          {Array.from({ length: 48 }, (_, i) => (
            <div
              key={i}
              className={`bg-gradient-to-br ${
                i % 3 === 0
                  ? "from-green-800 to-orange-500"
                  : i % 3 === 1
                  ? "from-orange-500 to-yellow-600"
                  : "from-yellow-600 to-green-800"
              } rounded-lg animate-float`}
              style={{ animationDelay: `${(i * 0.5) % 6}s` }}
            />
          ))}
        </div>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <h1 className="text-6xl md:text-8xl font-playfair font-bold mb-6 animate-fade-in">
          <span className="bg-gradient-to-r from-orange-500 via-yellow-400 to-orange-500 bg-clip-text text-transparent">
            Kashmir
          </span>
          <span className="text-white block mt-2">Heritage</span>
        </h1>
        <p className="text-xl md:text-2xl text-gray-300 mb-8 animate-slide-up font-light">
          Explore the Culture & History of Kashmir
        </p>
        <p
          className="text-lg text-gray-400 mb-12 animate-slide-up"
          style={{ animationDelay: "0.2s" }}
        >
          Preserving a timeless legacy of art, language, and identity
        </p>
        <div
          className="flex justify-center space-x-4 animate-slide-up"
          style={{ animationDelay: "0.4s" }}
        >
          <button className="bg-gradient-to-r from-orange-500 to-yellow-500 text-black px-8 py-3 rounded-full font-semibold hover:from-yellow-500 hover:to-orange-500 transition-all duration-300 transform hover:scale-105">
            Begin Journey
          </button>
          <button className="border-2 border-orange-500 text-orange-500 px-8 py-3 rounded-full font-semibold hover:bg-orange-500 hover:text-black transition-all duration-300">
            Explore Timeline
          </button>
        </div>
      </div>
    </section>
  );
}
