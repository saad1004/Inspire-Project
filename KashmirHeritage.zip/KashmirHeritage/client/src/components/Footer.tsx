import { Facebook, Twitter, Instagram, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-green-800/20 border-t border-orange-500/20 mt-20 py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h4 className="text-xl font-playfair font-semibold text-orange-500 mb-4">
              Kashmir Heritage
            </h4>
            <p className="text-gray-300 text-sm">
              Preserving and celebrating the rich cultural legacy of Kashmir through digital storytelling.
            </p>
          </div>
          <div>
            <h5 className="font-semibold text-white mb-4">Explore</h5>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Historic Sites
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Art & Culture
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Timeline
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Geography
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold text-white mb-4">Resources</h5>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Digital Archive
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Research Papers
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Photo Gallery
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-500 transition-colors">
                  Bibliography
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold text-white mb-4">Connect</h5>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors">
                <Youtube size={20} />
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-orange-500/20 mt-8 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; 2025 Kashmir Heritage Portal. Preserving culture through technology.</p>
        </div>
      </div>
    </footer>
  );
}
