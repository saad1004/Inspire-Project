import BentoBox from "@/components/BentoBox";
import { 
  Newspaper, 
  Landmark, 
  Palette, 
  Music, 
  User, 
  Utensils, 
  Languages, 
  Clock, 
  GraduationCap, 
  Mountain, 
  Shield 
} from "lucide-react";

const bentoData = [
  {
    id: "news",
    title: "Kashmir Today",
    icon: Newspaper,
    className: "md:col-span-2 lg:col-span-2 xl:col-span-2",
    gradient: "from-green-800/30 to-yellow-600/20",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300",
    imageAlt: "Dal Lake with houseboats",
    description: "Latest updates and developments in the Kashmir Valley, covering cultural events, tourism initiatives, and community stories.",
    expandedContent: (
      <div className="space-y-3">
        <div className="border-l-4 border-orange-500 pl-4">
          <h4 className="font-semibold text-orange-500">Saffron Harvest Festival Celebrates Bumper Crop</h4>
          <p className="text-sm text-gray-400">Pampore witnesses record saffron production this season</p>
        </div>
        <div className="border-l-4 border-orange-500 pl-4">
          <h4 className="font-semibold text-orange-500">Traditional Crafts Exhibition Opens in Srinagar</h4>
          <p className="text-sm text-gray-400">Showcasing centuries-old Kashmiri handicrafts</p>
        </div>
        <div className="border-l-4 border-orange-500 pl-4">
          <h4 className="font-semibold text-orange-500">Digital Archive Project Preserves Kashmiri Literature</h4>
          <p className="text-sm text-gray-400">Ancient manuscripts and poetry being digitized</p>
        </div>
      </div>
    )
  },
  {
    id: "historic",
    title: "Historic Sites",
    icon: Landmark,
    className: "",
    gradient: "from-yellow-600/30 to-green-800/20",
    image: "https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
    imageAlt: "Ancient Kashmiri temple ruins",
    description: "Explore Kashmir's architectural marvels spanning centuries",
    expandedContent: (
      <div className="space-y-2 text-sm">
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Shankaracharya Temple - Spiritual pinnacle</span>
        </div>
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Martand Sun Temple - 8th century marvel</span>
        </div>
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Pari Mahal - Garden of fairies</span>
        </div>
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Hazratbal Shrine - Sacred Islamic site</span>
        </div>
      </div>
    )
  },
  {
    id: "art",
    title: "Art & Handicrafts",
    icon: Palette,
    className: "",
    gradient: "from-orange-500/30 to-green-800/20",
    image: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
    imageAlt: "Traditional Kashmiri crafts",
    description: "Masterful traditions passed through generations",
    expandedContent: (
      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full inline-block mr-1"></div>
          <span>Pashmina Weaving</span>
        </div>
        <div className="text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full inline-block mr-1"></div>
          <span>Papier-mâché</span>
        </div>
        <div className="text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full inline-block mr-1"></div>
          <span>Carpet Weaving</span>
        </div>
        <div className="text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full inline-block mr-1"></div>
          <span>Kani Shawls</span>
        </div>
      </div>
    )
  },
  {
    id: "music",
    title: "Music & Literature",
    icon: Music,
    className: "md:col-span-2 lg:col-span-2",
    gradient: "from-green-800/30 to-orange-500/20",
    image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=250",
    imageAlt: "Traditional Kashmiri music performance",
    description: "The soul of Kashmir expressed through mystical verses and melodies",
    expandedContent: (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Sufiana Music</h4>
          <p className="text-sm text-gray-400">Classical spiritual music tradition with Persian influences</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Lalla Ded (Lal Ded)</h4>
          <p className="text-sm text-gray-400">14th century mystic poet and saint</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Habba Khatoon</h4>
          <p className="text-sm text-gray-400">16th century poetess, the nightingale of Kashmir</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Kashmiri Poetry</h4>
          <p className="text-sm text-gray-400">Rich tradition of verses in Koshur language</p>
        </div>
      </div>
    )
  },
  {
    id: "attire",
    title: "Traditional Attire",
    icon: User,
    className: "",
    gradient: "from-yellow-600/30 to-orange-500/20",
    image: "https://images.unsplash.com/photo-1517495306984-f84210f9daa8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
    imageAlt: "Traditional Kashmiri clothing",
    description: "Elegance woven into daily life",
    expandedContent: (
      <div className="space-y-3 text-sm">
        <div>
          <h4 className="font-semibold text-orange-500">Pheran</h4>
          <p className="text-gray-400">Traditional long overcoat for both men and women</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500">Taranga</h4>
          <p className="text-gray-400">Traditional headgear for Kashmiri women</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500">Wedding Attire</h4>
          <p className="text-gray-400">Elaborate ceremonial outfits with intricate embroidery</p>
        </div>
      </div>
    )
  },
  {
    id: "cuisine",
    title: "Cuisine",
    icon: Utensils,
    className: "",
    gradient: "from-orange-500/30 to-yellow-600/20",
    image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
    imageAlt: "Traditional Kashmiri cuisine",
    description: "A feast for the soul",
    expandedContent: (
      <div className="space-y-2 text-sm">
        <div className="flex items-center justify-between text-gray-300">
          <span>Wazwan</span>
          <span className="text-orange-500">Multi-course feast</span>
        </div>
        <div className="flex items-center justify-between text-gray-300">
          <span>Rogan Josh</span>
          <span className="text-orange-500">Aromatic lamb curry</span>
        </div>
        <div className="flex items-center justify-between text-gray-300">
          <span>Noon Chai</span>
          <span className="text-orange-500">Pink salt tea</span>
        </div>
        <div className="flex items-center justify-between text-gray-300">
          <span>Kahwah</span>
          <span className="text-orange-500">Spiced green tea</span>
        </div>
      </div>
    )
  },
  {
    id: "language",
    title: "Language & Scripts",
    icon: Languages,
    className: "md:col-span-2",
    gradient: "from-green-800/30 to-yellow-600/20",
    image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=200",
    imageAlt: "Ancient Kashmiri manuscript",
    description: "The written legacy of Kashmir - from ancient scripts to modern preservation",
    expandedContent: (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Sharada Script</h4>
          <p className="text-gray-400">Ancient Brahmic script used for Sanskrit and Kashmiri</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Koshur Language</h4>
          <p className="text-gray-400">Native Kashmiri language with rich oral tradition</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Persian Influence</h4>
          <p className="text-gray-400">Literary and administrative language legacy</p>
        </div>
      </div>
    )
  },
  {
    id: "timeline",
    title: "Historical Timeline",
    icon: Clock,
    className: "md:col-span-2 lg:col-span-3 xl:col-span-2",
    gradient: "from-yellow-600/30 to-green-800/20",
    image: "https://images.unsplash.com/photo-1461360370896-922624d12aa1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=200",
    imageAlt: "Historical timeline",
    description: "Journey through Kashmir's rich historical periods",
    expandedContent: (
      <div className="space-y-4">
        <div className="flex items-center space-x-4 p-3 bg-green-800/20 rounded-lg">
          <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
          <div>
            <h4 className="font-semibold text-orange-500">Mauryan Period (3rd century BCE)</h4>
            <p className="text-sm text-gray-400">Buddhism flourishes under Ashoka's rule</p>
          </div>
        </div>
        <div className="flex items-center space-x-4 p-3 bg-yellow-600/20 rounded-lg">
          <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
          <div>
            <h4 className="font-semibold text-orange-500">Mughal Era (1586-1751)</h4>
            <p className="text-sm text-gray-400">Gardens and architectural marvels</p>
          </div>
        </div>
        <div className="flex items-center space-x-4 p-3 bg-orange-500/20 rounded-lg">
          <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
          <div>
            <h4 className="font-semibold text-orange-500">Dogra Rule (1846-1947)</h4>
            <p className="text-sm text-gray-400">Princely state under Maharaja Gulab Singh</p>
          </div>
        </div>
      </div>
    )
  },
  {
    id: "saints",
    title: "Saints & Scholars",
    icon: GraduationCap,
    className: "",
    gradient: "from-orange-500/30 to-green-800/20",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
    imageAlt: "Kashmir spiritual heritage",
    description: "Spiritual luminaries who shaped Kashmir",
    expandedContent: (
      <div className="space-y-3 text-sm">
        <div>
          <h4 className="font-semibold text-orange-500">Sheikh Noor-ud-din</h4>
          <p className="text-gray-400">14th century Sufi saint and poet</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500">Lal Ded</h4>
          <p className="text-gray-400">Mystic poetess and spiritual teacher</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500">Abhinavagupta</h4>
          <p className="text-gray-400">10th century philosopher and aesthetician</p>
        </div>
      </div>
    )
  },
  {
    id: "geography",
    title: "Geography & Valleys",
    icon: Mountain,
    className: "md:col-span-2",
    gradient: "from-green-800/30 to-orange-500/20",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=200",
    imageAlt: "Kashmir valley landscape",
    description: "Paradise on Earth - Kashmir's breathtaking natural beauty",
    expandedContent: (
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Dal Lake</span>
        </div>
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Gulmarg</span>
        </div>
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Sonamarg</span>
        </div>
        <div className="flex items-center text-gray-300">
          <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
          <span>Pahalgam</span>
        </div>
      </div>
    )
  },
  {
    id: "preservation",
    title: "Cultural Preservation",
    icon: Shield,
    className: "md:col-span-2 lg:col-span-4 xl:col-span-2",
    gradient: "from-yellow-600/30 to-green-800/20",
    image: "https://images.unsplash.com/photo-1544027993-37dbfe43562a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=200",
    imageAlt: "Cultural preservation efforts",
    description: "Safeguarding Kashmir's heritage for future generations",
    expandedContent: (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Digital Archives</h4>
          <p className="text-gray-400">Preserving manuscripts, music, and oral traditions through technology</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Craft Revival</h4>
          <p className="text-gray-400">Supporting artisans and traditional handicraft communities</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Language Programs</h4>
          <p className="text-gray-400">Educational initiatives to preserve Kashmiri language</p>
        </div>
        <div>
          <h4 className="font-semibold text-orange-500 mb-2">Cultural Centers</h4>
          <p className="text-gray-400">Establishing institutions for heritage education</p>
        </div>
      </div>
    )
  }
];

export default function MagicBento() {
  return (
    <section className="container mx-auto px-6 py-20">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 auto-rows-auto">
        {bentoData.map((item) => (
          <BentoBox key={item.id} {...item} />
        ))}
      </div>
    </section>
  );
}
