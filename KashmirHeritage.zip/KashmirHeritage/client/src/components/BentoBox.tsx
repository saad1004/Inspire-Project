import { useState } from "react";
import { LucideIcon } from "lucide-react";

interface BentoBoxProps {
  id: string;
  title: string;
  icon: LucideIcon;
  className?: string;
  gradient: string;
  image: string;
  imageAlt: string;
  description: string;
  expandedContent: React.ReactNode;
}

export default function BentoBox({
  title,
  icon: Icon,
  className = "",
  gradient,
  image,
  imageAlt,
  description,
  expandedContent,
}: BentoBoxProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div
      className={`bento-box bg-gradient-to-br ${gradient} border border-orange-500/20 rounded-xl p-6 cursor-pointer ${className}`}
      onClick={toggleExpand}
    >
      <div className="flex items-center mb-4">
        <Icon className="text-orange-500 text-2xl mr-3" size={24} />
        <h3 className="text-xl font-semibold text-white">{title}</h3>
      </div>
      
      <img
        src={image}
        alt={imageAlt}
        className="w-full h-32 object-cover rounded-lg mb-4"
        style={{ height: title === "Music & Literature" ? "160px" : "128px" }}
      />
      
      <p className="text-gray-300 mb-4 text-sm">{description}</p>
      
      <div className={`expandable-content ${isExpanded ? "expanded" : ""}`}>
        {expandedContent}
      </div>
    </div>
  );
}
