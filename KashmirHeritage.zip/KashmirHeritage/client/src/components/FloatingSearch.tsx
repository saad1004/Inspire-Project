import { useState } from "react";
import { Search } from "lucide-react";

export default function FloatingSearch() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    // TODO: Implement search functionality
    console.log("Search query:", e.target.value);
  };

  return (
    <div className="fixed top-6 right-6 z-50 search-float">
      <div
        className={`bg-green-800/20 border border-orange-500/30 rounded-full p-3 cursor-pointer transition-all duration-300 flex items-center ${
          isExpanded ? "w-64" : "w-12 h-12"
        }`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <Search className={`text-orange-500 ${isExpanded ? "mr-3" : ""}`} size={20} />
        {isExpanded && (
          <input
            type="text"
            placeholder="Search heritage topics..."
            className="bg-transparent text-white outline-none flex-1"
            value={searchQuery}
            onChange={handleSearch}
            onClick={(e) => e.stopPropagation()}
          />
        )}
      </div>
    </div>
  );
}
