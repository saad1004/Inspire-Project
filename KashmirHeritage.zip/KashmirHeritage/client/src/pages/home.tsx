import { useEffect } from "react";
import HeroSection from "@/components/HeroSection";
import MagicBento from "@/components/MagicBento";
import FloatingSearch from "@/components/FloatingSearch";
import Footer from "@/components/Footer";
import { useGSAP } from "@/hooks/use-gsap";

export default function Home() {
  const { animateOnScroll, animateHero } = useGSAP();

  useEffect(() => {
    animateHero();
    animateOnScroll();
  }, [animateHero, animateOnScroll]);

  return (
    <div className="bg-dark-bg text-gray-100 font-inter overflow-x-hidden">
      <FloatingSearch />
      <HeroSection />
      <MagicBento />
      <Footer />
    </div>
  );
}
