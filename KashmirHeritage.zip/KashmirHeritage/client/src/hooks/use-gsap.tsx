import { useCallback } from "react";

export function useGSAP() {
  const animateHero = useCallback(() => {
    // Since GSAP isn't available in this environment, we'll use CSS animations
    // This hook provides a consistent API for animation controls
    const heroElements = document.querySelectorAll('.animate-fade-in, .animate-slide-up');
    heroElements.forEach((element, index) => {
      const htmlElement = element as HTMLElement;
      htmlElement.style.animationDelay = `${index * 0.2}s`;
    });
  }, []);

  const animateOnScroll = useCallback(() => {
    // Intersection Observer for scroll animations
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const bentoBoxes = document.querySelectorAll('.bento-box');
    bentoBoxes.forEach((box) => {
      observer.observe(box);
    });

    return () => {
      bentoBoxes.forEach((box) => {
        observer.unobserve(box);
      });
    };
  }, []);

  return { animateHero, animateOnScroll };
}
